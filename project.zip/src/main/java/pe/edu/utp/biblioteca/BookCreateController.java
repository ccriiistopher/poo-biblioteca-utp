package pe.edu.utp.biblioteca;

import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import pe.edu.utp.biblioteca.model.Libro;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

public class BookCreateController implements Initializable {
    @FXML
    public ImageView img_picture;

    @FXML
    public TextField field_title;

    @FXML
    public TextField field_author;

    @FXML
    public TextField field_isbn;

    @FXML
    public TextField field_genre;

    @FXML
    public MenuButton button_menu_genre;

    @FXML
    public ButtonType button_add;

    private DialogPane dialogPane;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        field_title.setTooltip(new Tooltip("AAAA"));
        String[] generos = {"Ficción", "Fantasía", "Ciencia Ficción", "Romance", "Suspenso",
                "Misterio", "Terror", "Biografía", "No Ficción", "Histórico"};
        for (String genero : generos) {
            MenuItem generoItem = new MenuItem(genero);
            button_menu_genre.getItems().add(generoItem);
        }

    }

    @FXML
    public void pickPicture() {
        FileChooser chooser = new FileChooser();
        chooser.setSelectedExtensionFilter(new FileChooser.ExtensionFilter("PNG", "*.png"));
        File file = chooser.showOpenDialog(null);
        img_picture.setImage(new Image(file.toURI().toString()));
    }

    public void setDialogPane(DialogPane dialogPane) {
        this.dialogPane = dialogPane;
        this.dialogPane.lookupButton(button_add).addEventFilter(ActionEvent.ANY, event -> {
            Libro libro = new Libro(field_title.getText(), field_author.getText(), field_genre.getText(), field_isbn.getText());
        });


    }
}

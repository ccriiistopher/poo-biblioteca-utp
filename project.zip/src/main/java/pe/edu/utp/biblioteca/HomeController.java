package pe.edu.utp.biblioteca;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import pe.edu.utp.biblioteca.model.Libro;
import pe.edu.utp.biblioteca.ui.BookCellFactory;
import pe.edu.utp.biblioteca.ui.BookCreateDialog;

import java.io.IOException;
import java.util.ArrayList;

public class HomeController {

    private ObservableList<Libro> books = FXCollections.observableArrayList();
    @FXML
    public ListView<Libro> list_books;

    @FXML
    public Button button_add_book;

    public void initialize() {
        books.add(new Libro(
                "Romeo y Julieta",
                "William Shakespeare",
                "Drama",
                "0000"
        ));
        list_books.setCellFactory(new BookCellFactory());
        list_books.setItems(
                books
        );
        list_books.setFixedCellSize(150);
    }


    @FXML
    public void onAddNewBook() {
        System.out.println("Adding new book");
        BookCreateDialog bookCreateDialog = null;
        bookCreateDialog = new BookCreateDialog(App.globalStage);

        bookCreateDialog.showAndWait();
    }
}

package pe.edu.utp.biblioteca;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import pe.edu.utp.biblioteca.model.Libro;

public class BookCellController {
    private Libro book;

    @FXML
    public Label label_title, label_author, label_genre, label_isbn;

    @FXML
    public CheckBox checkbox_available;

    @FXML
    public ImageView image_book;

    public void setLibro(Libro book) {
        this.book = book;

        if( book == null) {

        }
        else {
            label_title.setText(book.getTitulo());
            label_author.setText(book.getAutor());
            label_genre.setText(book.getGenero());
        }
    }
}

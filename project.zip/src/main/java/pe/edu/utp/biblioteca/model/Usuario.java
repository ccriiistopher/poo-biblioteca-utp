package pe.edu.utp.biblioteca.model;

public class Usuario {
    private String nombres, apellidos, dni, contrasena;
    private TipoUsuario tipoUsuario;

    public Usuario(String nombres, String apellidos, String dni, String contrasena, TipoUsuario tipo) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dni = dni;
        this.tipoUsuario = tipo;
        this.contrasena = contrasena;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public TipoUsuario getTipo() {
        return tipoUsuario;
    }

    public void setTipo(TipoUsuario tipo) {
        this.tipoUsuario = tipo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    
    public static enum TipoUsuario {
        Admin, Alumno, Profesor
    }
}

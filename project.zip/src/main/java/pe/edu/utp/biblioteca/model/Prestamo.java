package pe.edu.utp.biblioteca.model;

public class Prestamo {
    private Usuario usuario;
    private Libro libro;
    
}
